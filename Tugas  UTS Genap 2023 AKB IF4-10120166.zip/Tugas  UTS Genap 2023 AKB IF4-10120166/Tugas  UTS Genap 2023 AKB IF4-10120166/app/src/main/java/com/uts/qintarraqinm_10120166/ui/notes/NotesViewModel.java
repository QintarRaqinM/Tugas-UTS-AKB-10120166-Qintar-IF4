/**
 *
 * Nama : Qintar Raqin Maulana
 * Nim : 10120166
 * Kelas : IF 4
 * Email : qintarraqin14@gmail.com
 *
 */

package com.uts.qintarraqinm_10120166.ui.notes;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class NotesViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public NotesViewModel() {
        mText = new MutableLiveData<>();
    }

    public LiveData<String> getText() {
        return mText;
    }
}