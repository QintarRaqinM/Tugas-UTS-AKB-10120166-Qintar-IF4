/**
 *
 * Nama : Qintar Raqin Maulana
 * Nim : 10120166
 * Kelas : IF 4
 * Email : qintarraqin14@gmail.com
 *
 */

package com.uts.qintarraqinm_10120166;

public class NoteModel {
    int id;
    String title, description, category, created_at, updated_at;
}
